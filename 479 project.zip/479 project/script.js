// Mock user data (replace with backend implementation)
const users = [
    { username: 'user1', password: 'password1' },
    { username: 'user2', password: 'password2' }
];

function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        hideForms();
        showDashboard();
    } else {
        alert('Invalid username or password');
    }
}

function signup() {
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;

    // Mock user registration (replace with backend implementation)
    users.push({ username, password });
    hideForms();
    showDashboard();
}

function logout() {
    hideDashboard();
    showForms();
}

function hideForms() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('signup-form').style.display = 'none';
}

function showForms() {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('signup-form').style.display = 'block';
}

function showDashboard() {
    document.getElementById('dashboard').style.display = 'block';
}

function hideDashboard() {
    document.getElementById('dashboard').style.display = 'none';
}
